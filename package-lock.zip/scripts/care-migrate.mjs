import 'dotenv/config'
import mongoose from 'mongoose'
import User from '../src/models/User.js'
import Booking from '../src/models/Booking.js'
import * as models from '../src/care/models.js'
if(!process.env.MONGODB_URI)throw new Error('Set MONGODB_URI in backend/.env first.')
try{
 await mongoose.connect(process.env.MONGODB_URI)
 const result=await User.updateMany({role:'user'},{$set:{role:'mother'}})
 await User.updateMany({status:{$exists:false}},{$set:{status:'active'}})
 for(const model of [User,Booking,...Object.values(models)])if(typeof model?.createIndexes==='function')await model.createIndexes()
 console.log(`Migrated ${result.modifiedCount} customer roles to mother. Indexes created. No accounts or bookings were removed.`)
}finally{await mongoose.disconnect()}
